<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>权限不足</title>
    <link href="style/register.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div>
    <div class="tita">请重新输入</div>
    <iframe src="//www.bilibili.com/blackboard/html5mobileplayer.html?isOutside=true&aid=651820362&bvid=BV1he4y1w7wB&cid=1006811391&p=1&autoplay=1&muted=0" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"></iframe>
    <a id="tuichu" class="tita" href="login.php">返回上级&nbsp;</a>
    </div>   
    <div class="square">
            <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>  
        </div>
        <div class="circle">
            <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </div>
</body>
</html>