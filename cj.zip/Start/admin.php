<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>信息记录管理主页面</title>
<link href="style/style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="box">
  <div id="left"><img src="images/403.jpg" width="141" height="75" alt=""><img src="images/404.jpg" width="141" height="69" alt=""><img src="images/405.jpg" width="141" height="69" alt=""><img src="images/406.jpg" width="141" height="69" alt=""><img src="images/407.jpg" width="141" height="69" alt=""><img src="images/408.jpg" width="141" height="69" alt=""><img src="images/409.jpg" width="141" height="69" alt=""><img src="images/410.jpg" width="141" height="69" alt=""></div>
  <div id="right">
    <div id="top"><img src="images/411.png" width="854" height="72" alt=""></div>
    <div id="main-title"><img src="images/412.png" width="841" height="60" alt=""></div>
    <div id="main-bg">
      <div id="jishu">共有条记录，目前显示第条至第条<img src="images/413.png" width="60" height="22" alt=""></div>
      <div id="title2">
        <ul>
          <li>姓名</li>
          <li>年龄</li>
          <li>性别</li>
          <li>班级</li>
          <li>语文</li>
          <li>数学</li>
          <li>英语</li>
          <li>综合</li>
          <li>操作</li>
        </ul>
      </div>
      <div class="list2">
        <ul>
          <li>名字</li>
          <li>年龄</li>
          <li>性别</li>
          <li>班</li>
          <li>成绩</li>
          <li>成绩</li>
          <li>成绩</li>
          <li>成绩</li>
          <li>[修改] [删除]</li>
        </ul>
      </div>
      <div class="list1" style="text-align:center;">目前还没有添加任何信息</div>
      <div id="bar">第一页　上一页　下一页　最后一页　</div>
    </div>
  </div>
</div>
</body>
</html>
