<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>详细信息显示页面</title>
<link href="style/style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="box">
  <div id="left"><img src="images/403.jpg" width="141" height="75" alt=""><img src="images/404.jpg" width="141" height="69" alt=""><img src="images/405.jpg" width="141" height="69" alt=""><img src="images/406.jpg" width="141" height="69" alt=""><img src="images/407.jpg" width="141" height="69" alt=""><img src="images/408.jpg" width="141" height="69" alt=""><img src="images/409.jpg" width="141" height="69" alt=""><img src="images/410.jpg" width="141" height="69" alt=""></div>
  <div id="right">
    <div id="top"><img src="images/411.png" width="854" height="72" alt=""></div>
    <div id="main-title"><img src="images/412.png" width="841" height="60" alt=""></div>
    <div id="main-bg">
      <div id="title1">
        <ul>
          <li>姓名</li>
          <li>年龄</li>
          <li>性别</li>
          <li>班级</li>
          <li>语文</li>
          <li>数学</li>
          <li>英语</li>
          <li>综合 </li>
        </ul>
      </div>
      <div class="list1">
        <ul>
          <li>名字</li>
          <li>年龄</li>
          <li>性别</li>
          <li>班</li>
          <li>成绩</li>
          <li>成绩</li>
          <li>成绩</li>
          <li>成绩</li>
        </ul>
      </div>
    </div>
  </div>
</div>
</body>
</html>
